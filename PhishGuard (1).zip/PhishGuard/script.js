const urlInput = document.getElementById('urlInput');
const messageInput = document.getElementById('messageInput');
const analyzeButton = document.getElementById('analyzeButton');
const scanNowButton = document.getElementById('scanNowButton');
const getStartedButton = document.getElementById('getStartedButton');
const viewDemoButton = document.getElementById('viewDemoButton');
const exportButton = document.getElementById('exportButton');
const featureCards = document.querySelectorAll('.feature-card');
const severityBadge = document.getElementById('severityBadge');
const scoreValue = document.getElementById('scoreValue');
const scoreLabel = document.getElementById('scoreLabel');
const riskList = document.getElementById('riskList');
const recommendationText = document.getElementById('recommendationText');

function evaluateThreat(url, message) {
  const normalizedUrl = url.toLowerCase();
  const normalizedMessage = message.toLowerCase();

  let score = 18;
  let reasons = [];

  const suspiciousPatterns = [
    'verify',
    'secure',
    'urgent',
    'immediately',
    'suspended',
    'account',
    'action required',
    'click here',
    'login',
    'payment',
    'bank',
    'paypal',
    'amazon',
    'confirm'
  ];

  suspiciousPatterns.forEach((pattern) => {
    if (normalizedUrl.includes(pattern) || normalizedMessage.includes(pattern)) {
      score += 8;
    }
  });

  if (normalizedUrl.includes('paypal') || normalizedUrl.includes('amazon')) {
    reasons.push('Brand impersonation detected through familiar domain naming.');
    score += 10;
  }

  if (normalizedUrl.includes('verify') || normalizedUrl.includes('secure-login')) {
    reasons.push('The URL uses a crafted login flow to mimic a trustworthy service.');
    score += 12;
  }

  const urgencyTriggers = ['urgent', 'immediately', 'suspended', 'action required'];
  urgencyTriggers.forEach((trigger) => {
    if (normalizedMessage.includes(trigger)) {
      reasons.push('Urgency language is encouraging quick action without verification.');
      score += 8;
    }
  });

  if (!url.includes('.') || url.includes('..')) {
    reasons.push('URL structure is malformed or missing a trusted hostname.');
    score += 10;
  }

  if (reasons.length === 0) {
    reasons.push('No major phishing indicators were found in the provided content.');
  }

  score = Math.min(score, 98);

  if (score >= 75) {
    severityBadge.textContent = 'High Risk';
    severityBadge.className = 'result-severity high';
    scoreLabel.textContent = 'High-confidence phishing attempt';
    recommendationText.textContent = 'Block the link immediately, notify the sender, and instruct the user to verify the request through the official website instead of the provided link.';
  } else if (score >= 45) {
    severityBadge.textContent = 'Moderate Risk';
    severityBadge.className = 'result-severity moderate';
    scoreLabel.textContent = 'Suspicious activity detected';
    recommendationText.textContent = 'Flag the message for review, isolate the link, and ask the user to confirm the request through trusted channels.';
  } else {
    severityBadge.textContent = 'Low Risk';
    severityBadge.className = 'result-severity safe';
    scoreLabel.textContent = 'Looks relatively safe';
    recommendationText.textContent = 'No immediate issues detected, but continue monitoring and review any unusual account activity.';
  }

  scoreValue.textContent = Math.round(score);

  const uniqueReasons = [...new Set(reasons)];
  riskList.innerHTML = uniqueReasons
    .slice(0, 4)
    .map((reason) => `<li>${reason}</li>`)
    .join('');

  if (score >= 75) {
    document.querySelector('.score-ring').style.background = 'conic-gradient(var(--danger) 0 80%, rgba(255,255,255,0.08) 80% 100%)';
  } else if (score >= 45) {
    document.querySelector('.score-ring').style.background = 'conic-gradient(var(--warning) 0 73%, rgba(255,255,255,0.08) 73% 100%)';
  } else {
    document.querySelector('.score-ring').style.background = 'conic-gradient(var(--success) 0 35%, rgba(255,255,255,0.08) 35% 100%)';
  }
}

function handleAnalyze() {
  const url = urlInput.value.trim();
  const message = messageInput.value.trim();

  if (!url && !message) {
    alert('Please enter a URL or a message to scan.');
    return;
  }

  evaluateThreat(url || 'example.com', message || 'No message provided');
}

function exportReport() {
  const url = (urlInput.value || '').trim() || 'Not provided';
  const message = (messageInput.value || '').trim() || 'Not provided';
  const severity = severityBadge.textContent || 'Unknown';
  const score = scoreValue.textContent || '0';
  const label = scoreLabel.textContent || 'No label';
  const reasons = [...riskList.querySelectorAll('li')].map((item) => item.textContent.trim());
  const recommendation = recommendationText.textContent || 'No recommendation';

  const report = [
    'PhishGuard Security Report',
    '========================',
    `Timestamp: ${new Date().toLocaleString()}`,
    `URL: ${url}`,
    `Message: ${message}`,
    `Severity: ${severity}`,
    `Score: ${score}%`,
    `Status: ${label}`,
    '',
    'Risk Findings:',
    ...reasons.map((reason, index) => `${index + 1}. ${reason}`),
    '',
    'Recommended Action:',
    recommendation
  ].join('\n');

  const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = 'phishguard-report.txt';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(blobUrl);
}

function runFeatureDemo(type) {
  const demoConfig = {
    url: {
      url: 'https://secure-login-paypal-verify.com/account',
      message: 'Please verify your account now to avoid suspension.'
    },
    email: {
      url: 'https://bank-secure-update.com/login',
      message: 'Urgent action required. Your account will be suspended unless you confirm your identity immediately.'
    },
    risk: {
      url: 'https://support-portal-account.net/confirm',
      message: 'Click here to approve payment and avoid a temporary hold.'
    }
  };

  const selected = demoConfig[type] || demoConfig.url;
  urlInput.value = selected.url;
  messageInput.value = selected.message;

  document.getElementById('scanner').scrollIntoView({ behavior: 'smooth', block: 'start' });
  setTimeout(() => evaluateThreat(selected.url, selected.message), 300);
}

analyzeButton.addEventListener('click', handleAnalyze);
scanNowButton.addEventListener('click', () => {
  document.getElementById('scanner').scrollIntoView({ behavior: 'smooth', block: 'start' });
  handleAnalyze();
});

getStartedButton.addEventListener('click', () => {
  document.getElementById('scanner').scrollIntoView({ behavior: 'smooth', block: 'start' });
  setTimeout(() => {
    evaluateThreat(urlInput.value, messageInput.value);
  }, 300);
});

viewDemoButton.addEventListener('click', () => {
  document.getElementById('scanner').scrollIntoView({ behavior: 'smooth', block: 'start' });
  setTimeout(() => {
    evaluateThreat(urlInput.value, messageInput.value);
  }, 300);
});

featureCards.forEach((card) => {
  card.addEventListener('click', () => {
    runFeatureDemo(card.dataset.demo);
  });
});

exportButton.addEventListener('click', exportReport);

window.addEventListener('DOMContentLoaded', () => {
  evaluateThreat(urlInput.value, messageInput.value);
});
